First open up a terminal. Then type:   
make   

To run my program you can do(this is a sample):
./router 30000   
./router 30100 30200 2   
./router 30200 30300 3   
...

I attched a picture of a sample inputs you could type to the command line
to make sure it works. I have the input below you can enter. Just open up
5 terminal windows and type each command from 1 to 5 in the command line

./router 30400.  
./router 30000 30400 3  
./router 30300 30000 6   
./router 30200 30100 1     
./router 30100 30000 1       

